<?php
ini_set('display_errors', 1); error_reporting(E_ALL);
ini_set('display_startup_errors', 1);
// ini_set('session.save_path', '/var/lib/php/tempsessions');
    
session_start();
    include '../connection/dbconnection.php';
    require '../model/userdata.php';
    require '../model/postdata.php';
    require '../smarty/libs/Smarty.class.php';

    // require 'smarty/libs/Smarty.class.php';

    $db = new Db();
    $smarty = new Smarty;
    if(isset($_SESSION['loggedin'])){
        $loggedin = $_SESSION['loggedin'];
        $sessuser = $_SESSION['username'];
        $sessuserid = $_SESSION['userid'];
        $userdata = new Userdata();
        $sqlpost1 = $userdata->getusername();
        $smarty->assign('user_type',$sqlpost1['user_type']);
        $smarty->assign('loggedin',$loggedin);
        $smarty->assign('username',$sessuser);
        $smarty->assign('userid',$sessuserid);
    }

    $postdata = new PostData();
   
    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])){
        $search = $_POST['search'];
        $sqlpost = $postdata->search($search);
    }else{
        $sqlpost = $postdata->getRecord();
    }

    $smarty->assign('title','JOBPORTAL-HOME');
    $smarty->assign('postdata',$sqlpost);

    $smarty->display('home.tpl');
?>