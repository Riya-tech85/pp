<?php
    session_start();
    require '../smarty/libs/Smarty.class.php';

    $smarty = new Smarty();
    if($_GET){
        $smarty->assign('joblocation',$_GET['employer_location']);
        $smarty->assign('jobtitle',$_GET['employer_jobtitle']);
        $smarty->assign('jobemail',$_GET['employer_email']);
        $smarty->assign('employername',$_GET['employer_name']);
        $smarty->assign('image',$_GET['img']);
        $smarty->assign('date',$_GET['date']);
        $smarty->assign('id',$_GET['id']);
    }

        $smarty->display('editpublish.tpl');
?>