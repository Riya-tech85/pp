<?php
/* Smarty version 4.3.1, created on 2023-06-02 18:15:57
  from '/home/users/riya.singh/www/html/project1/php/templates/applypage.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6479e4856f7703_82412270',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8ab4c2a1209430331fa315f229030b9bce95817b' => 
    array (
      0 => '/home/users/riya.singh/www/html/project1/php/templates/applypage.tpl',
      1 => 1685709954,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6479e4856f7703_82412270 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
    <title>JOBPORTAL-HOME</title>
    <link rel = "stylesheet" href = "../css/signin.css">
</head>
<body>
<nav class = "navbar navbar-expand-sm ">
        <div class="container">
            <span class="navbar-brand">
                <img src=""><span class ="text-white">JOBSTAKE</span>
            </span>
            <span class = "justify-content-end">
                <a href = "../php/logout.php"><button>LOGOUT</button></a>
                <a href = "../index.php"><button>BACK</button></a>
            </span>
        </div>
    </nav>
    <div class = "d-flex p-4 justify-content-center" style = "background-color : #00607e; margin : 0% 15%;" >
        <form method = "post" action = "../helper/applypage.php">
            <span class = "p-2"><input type = "search" name = "search" size = "50" placeholder = "Search for job here"></span>
            <span class = "p-2"><input type = "submit" value = "SEARCH FOR JOBS" style = "color : white;background-color : orange;"></span>
        </form>
    </div>
    <div id = "postunderview">
        REGISTERED
    </div>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['applydata']->value, 'x');
$_smarty_tpl->tpl_vars['x']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['x']->value) {
$_smarty_tpl->tpl_vars['x']->do_else = false;
?>
        <?php if ($_smarty_tpl->tpl_vars['username']->value == $_smarty_tpl->tpl_vars['x']->value['empoyee_name']) {?>
            <div class = "formcontainer p-3 d-flex mt-5">
                <div><img src = '<?php echo $_smarty_tpl->tpl_vars['x']->value['img'];?>
' width = "100px" height = "100px"></div>
                    <div class = "container" >
                        <b style = "color : blue;"><?php echo $_smarty_tpl->tpl_vars['x']->value['employer_title'];?>
</b>
                        <br>
                        Posted by - <?php echo $_smarty_tpl->tpl_vars['x']->value['employer_name'];?>
<br>
                        Posted on - <?php echo $_smarty_tpl->tpl_vars['x']->value['date'];?>
<br>
                        Location - <?php echo $_smarty_tpl->tpl_vars['x']->value['employer_location'];?>
 <br>
                        Contact Email - <?php echo $_smarty_tpl->tpl_vars['x']->value['employee_email'];?>

                    </div>
            </div>
        <?php }?>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</body>
</html><?php }
}
