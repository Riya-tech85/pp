<?php
/* Smarty version 4.3.1, created on 2023-06-02 18:35:18
  from '/home/users/riya.singh/www/html/project1/php/templates/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6479e90e9c8504_45671605',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f5459f9ae90e1c54495d4a04a80c59ebee45d78a' => 
    array (
      0 => '/home/users/riya.singh/www/html/project1/php/templates/home.tpl',
      1 => 1685711113,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6479e90e9c8504_45671605 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
    <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
    <link rel = "stylesheet" href = "../css/signin.css">
</head>
<body>
    <nav class = "navbar navbar-expand-sm ">
            <div class="container">
                <span class="navbar-brand">
                    <img src=""><span class ="text-white">JOBSTAKE</span>
                </span>
                <span class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                                                <?php if ((isset($_smarty_tpl->tpl_vars['loggedin']->value)) && $_smarty_tpl->tpl_vars['user_type']->value == 'Employer') {?>
                                <li class="nav-item">
                                <a class="nav-link" href="../helper/post.php">POSTJOB</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="../helper/view.php">viewpage</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="../index.php"><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="../php/logout.php"><button>LOGOUT</button></a>
                                </li>
                            <?php } elseif ((isset($_smarty_tpl->tpl_vars['loggedin']->value)) && $_smarty_tpl->tpl_vars['user_type']->value == 'Employee') {?>
                                <li class="nav-item">
                                <a class="nav-link" href="../helper/applypage.php">APPLYJOB</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="../index.php"><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="../php/logout.php"><button>LOGOUT</button></a>
                                </li>
                        <?php } else { ?>
                            <li class="nav-item">
                            <a class="nav-link" href="../helper/signin.php">SignIN</a>
                            </li>
                            <li class="nav-item">
                            <a class="nav-link" href="../helper/signup.php">SignUP</a>
                            </li>
                        <?php }?>
                    </ul>
                </span>
            </div>
    </nav>
    <?php ob_start();
echo $_smarty_tpl->tpl_vars['user_type']->value;
$_prefixVariable1 = ob_get_clean();
if ($_prefixVariable1 == 'Employer') {?>
        <div class = "container mt-5 p-5">
            <h1 class = "justify-content-center" style = "text-align : center; box-shadow: -0px 2px 3px 2px black;"> WELCOME TO JOBPORTAL </h1>
        </div>
    <?php } else { ?>
        <div class = "d-flex p-4 justify-content-center" style = "background-color : #00607e; margin : 0% 15%;" >
            <form method = "post" action = "../php/home.php">
                <span class = "p-2"><input type = "search" name = "search" size = "50" placeholder = "Search for job here"></span>
                 <span class = "p-2"><input type = "submit" value = "SEARCH FOR JOBS" style = "color : white;background-color : orange;"></span>
            </form>
        </div>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['postdata']->value, 'x');
$_smarty_tpl->tpl_vars['x']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['x']->value) {
$_smarty_tpl->tpl_vars['x']->do_else = false;
?>
            <?php ob_start();
echo $_smarty_tpl->tpl_vars['x']->value['publish'];
$_prefixVariable2 = ob_get_clean();
if ($_prefixVariable2 == 1) {?>
                <div class = "formcontainer p-3 d-flex mt-5">
                    <div><img src = '<?php echo $_smarty_tpl->tpl_vars['x']->value['img'];?>
' width = "100px" height = "100px"></div>
                    <div class = "container" >
                    <b style = "color : blue;"><?php echo $_smarty_tpl->tpl_vars['x']->value['employer_jobtitle'];?>
</b>
                    <br>
                    Posted by - <?php echo $_smarty_tpl->tpl_vars['x']->value['employer_name'];?>
<br>
                    Posted on - <?php echo $_smarty_tpl->tpl_vars['x']->value['date'];?>
<br>
                    Location - <?php echo $_smarty_tpl->tpl_vars['x']->value['employer_location'];?>
 <br>
                    Contact Email - <?php echo $_smarty_tpl->tpl_vars['x']->value['employer_email'];?>

                    </div>
                </div>
                <?php if ((isset($_smarty_tpl->tpl_vars['loggedin']->value)) && $_smarty_tpl->tpl_vars['user_type']->value == 'Employee') {?>
                    <div style = "margin: 3% 25%; ">
                        <form method = 'post' action = "../helper/applypage.php" class = "btn">
                            <input type="hidden" name="custId2" value="<?php echo $_smarty_tpl->tpl_vars['x']->value['id'];?>
">
                            <input type = "submit" value = "REGISTER" style = "background-color : orange;">
                        </form> 
                    </div>
                <?php }?>
            <?php }?>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    <?php }?>
</body>
</html>

<?php }
}
