<?php
/* Smarty version 4.3.1, created on 2023-06-02 18:51:48
  from '/home/users/riya.singh/www/html/project1/php/templates/signup.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6479ececa02e65_22646063',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '27f232cd0aebe5d7cfd769cdb2b042ba7e8be9d2' => 
    array (
      0 => '/home/users/riya.singh/www/html/project1/php/templates/signup.tpl',
      1 => 1685712105,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6479ececa02e65_22646063 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
    <link rel = "stylesheet" href = "../css/signin.css">
    <title>Signup</title>
</head>
<body>
    <nav class = "navbar navbar-expand-sm ">
        <div class="container">
            <span class="navbar-brand">
                <img src=""><span class ="text-white">JOBSTAKE</span>
            </span>
            <span class=" justify-content-end"><a href = "../index.php"><button>BACK</button></a></span>
        </div>
    </nav>
    
   <div class = "formcontainer">
    <form method = "post" action = "../helper/signup.php" class = "was-validated container" >
    <h1 style= "text-align: center;">SIGN UP</h1>
        <div class = "mb-3 mt-3">
            <label for ="name" class="form-label">Name: </label><br>
            <input type = "text" class = "form-control no-outline" id = "fullname1" placeholder = "Enter Name" name = "name" required >
        </div>
        <div class = "mb-3">
            <label for="username" id = "username1" class = "form-label">Username:</label><br>
            <input type = "text" class = "form-control no-outline" id  = "username1" placeholder = "Enter Username" name = "username" required>
        </div>
        <div class = "mb-3">
            <label for="email" class = "form-label">Email:</label><br>
            <input type = "email" class = "form-control no-outline" id  = "email1" placeholder = "Enter Email" name = "email" required>
        </div>
        
        <div class = "mb-3">
            <label class = "form-label">You are:</label><br>
           <select value = "select" id  = "usertype1" name = "usertype">
                <option>Employer</option>
                <option>Employee</option>
           </select>
        </div>
        <div class = "mb-3">
            <label for = "pwd" class = "form-label">Password:</label><br>
            <input type = "password" class = "form-control no-outline" placeholder = "Enter password" id = "pwd" name = "password" required>
        </div>
        <div class="mb-3">
            <input type = "submit" name = "submit">
        </div>
    </form>   
   </div>
   <?php echo '<script'; ?>
 src = "../js/signupvalidation.js"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
