<?php 
     ini_set('display_errors', 1);
     ini_set('display_startup_errors', 1);
     error_reporting(E_ALL);
     session_start();
    require '../smarty/libs/Smarty.class.php';

    $smarty =  new Smarty();

    $sessuser = $_SESSION['sessuser'];

    $smarty->assign('postdata',$_GET);
    $smarty->assign('username',$sessuser);
    
    $smarty->display('viewpage.tpl');
?>
