<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    session_start();
     require '../model/userdata.php';
     require '../model/postdata.php';
    require '../connection/dbconnection.php';

    $db = new Db();
    $postdata = new Postdata();
    $userdata = new Userdata();
    $username = $userdata->getusername();
    $_SESSION['sessuser'] = $username['full_name'];

    if($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['publish'])){
        $id = $_POST['publish'];
        $postdata->publishbutton($id);
        // echo "<script>window.location.replace('../php/viewpage.php');</script>";
    } 
    else if($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['unpublishbtn'])){
        $id = $_POST['unpublishbtn'];
        $postdata->publishbuttonoff($id);
        // echo "<script>window.location.replace('../php/viewpage.php');</script>";
    } 
    
    if($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['id'])){
        
        $location = $_POST['joblocation'];
        $title = $_POST['jobtitle'];
        $id = $_POST['id'];

        $filename=$_FILES['image']['name'];
        $tempname=$_FILES['image']['tmp_name'];
        $folder="picture/".$filename;
        move_uploaded_file($tempname,$folder);

        $postdata->updatepostdata($location,$title,$folder,$id);
    
        // echo "<script>window.location.replace('../php/viewpage.php');</script>";
    }
    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])){
        $search = $_POST['search'];
        $record = $postdata->search($search);
        $array1 = http_build_query($record);
        header("location: ../php/viewpage.php?{$array1}");
    }else{
        $record = $postdata->getRecord();
        $array1 = http_build_query($record);
        header("location: ../php/viewpage.php?{$array1}");
    }
?>