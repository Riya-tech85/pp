<?php
    session_start();
    require '../model/postdata.php';
    require '../connection/dbconnection.php';

    $db = new Db();

    $postdata = new Postdata();
    $sqlpost = $postdata->getpostid();
    $id = $sqlpost['id'];
      
    if($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['custId'])){
        $postdata->publishbutton($id);
        echo "<script>window.location.replace('../helper/view.php');</script>";
    } 
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $location = $_POST['joblocation'];
        $title = $_POST['jobtitle'];

        $filename=$_FILES['image']['name'];
        $tempname=$_FILES['image']['tmp_name'];
        $folder="../picture/".$filename;
        move_uploaded_file($tempname,$folder);

        $postdata->updatepostdata($location,$title,$folder,$id);
        $fetch = $postdata->getpostid();
        $array1 = http_build_query($fetch);

        header("location: ../php/editpublishpost.php?{$array1}");
    }
?>