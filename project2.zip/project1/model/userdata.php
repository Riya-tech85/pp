<?php

    class Userdata{
        private $username;
        private $email;
        private $fullname;
        private $usertype;
        private $password;
        private $employername;
        private $employerlocation;
        private $employertitle;
        private $employeremail;
        private $publish;
        private $folder;

        public function getusername(){
            $sql = "SELECT * FROM userinformation where user_name = :uname";
            $sql1 =  Db::getDbObject()->prepare($sql);
            $sql1->bindValue(':uname',$_SESSION['username']);
            $sql1->execute();
            $sqlpost1 = $sql1->fetch(PDO::FETCH_ASSOC);
            return $sqlpost1;
        }

        public function signin($username,$password){
            session_start();
            $sql1 =  Db::getDbObject()->prepare("select * from userinformation where user_name = :username and user_password = :password");
            $sql1->bindValue(":username",$username);
            $sql1->bindValue(":password",$password);
            $sql1->execute();
            $rowexist = $sql1->rowCount();
            if($rowexist > 0){
                $row = $sql1->fetch(PDO::FETCH_ASSOC);
                
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;
    
                $_SESSION['userid'] = $row['user_id'];
                return 0;
                
                // echo '<script>window.location.replace("index.php");</script>';
            }
            else{
                // echo "<script>alert('please enter correct username and password')</script>";
                return 1;
            }
        }

        public function signupdata($username,$email){
            $usernamesql = Db::getDbObject()->prepare("select * from userinformation where user_name = :username or user_email = :email");
            $usernamesql->bindValue(":username",$username);
            $usernamesql->bindValue(":email",$email);
            $usernamesql->execute();
            $result = $usernamesql->fetch(PDO::FETCH_ASSOC);
            return $result;
        }
        public function insertuserdata($username,$fullname,$usertype,$password,$email){
            $sql = Db::getDbObject()->prepare("INSERT INTO userinformation ( user_name, full_name, user_type, user_password, user_email) value (:username,:fullname,:usertype,:pass,:email)");
            $sql->bindValue(':username', $username);
            $sql->bindValue(':fullname', $fullname);
            $sql->bindValue(':usertype', $usertype);
            $sql->bindValue(':pass', $password);
            $sql->bindValue(':email', $email);
            $sql->execute();
            $sql1=  Db::getDbObject()->prepare("select * from userinformation where user_email = :email");
            $sql1->bindValue(':email', $email);
            $sql1->execute();

            $fetch = $sql1->fetch(PDO::FETCH_ASSOC);
        
            // echo "<script>alert('data successfully added')</script>";

            // $_SESSION['loggedin'] = true;
            // $_SESSION['username'] = $username;
            // $_SESSION['userid'] = $fetch['user_id'];
            return 1;
        
            // echo '<script>window.location.replace("helper/userhelper.php");</script>';
        }

        public function getuserid(){
            $sql1 = Db::getDbObject()->prepare("SELECT * FROM userinformation where user_id = :id");
            $sql1->bindValue(':id',$_SESSION['userid']);
            $sql1->execute();
            $sqlpost1 = $sql1->fetch(PDO::FETCH_ASSOC);
            return $sqlpost1;
        }
    }