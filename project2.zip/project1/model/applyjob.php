<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    class Applyjob{
        private $employeename;
        private $employeemail;
        private $employeelocation;
        private $employeetitle;
        private $image;
        private $sessuser;
        private $search;

        public function getapplyrecord(){
            $sql1 = Db::getDbObject()->prepare("SELECT * FROM applyjob ");
            $sql1->execute();
            $sqlapply = $sql1->fetchAll(PDO::FETCH_ASSOC);
            return $sqlapply;
        }

        public function insert($sessuser,$employeename,$employeemail,$employeelocation,$employeetitle,$image){
            $sql = "INSERT INTO applyjob (empoyee_name,employer_name,employee_email,employer_location,employer_title,img) value (:employeename,:employername,:employeeemail,:employeelocation,:employeetitle,:img)";

            $sqlregisterinsert = Db::getDbObject()->prepare($sql);
            $sqlregisterinsert->bindValue(':employeename',$sessuser);
            $sqlregisterinsert->bindValue(':employername',$employeename);
            $sqlregisterinsert->bindValue(':employeeemail',$employeemail);
            $sqlregisterinsert->bindValue(':employeelocation',$employeelocation);
            $sqlregisterinsert->bindValue(':employeetitle',$employeetitle);
            $sqlregisterinsert->bindValue(':img',$image);
            
            $sqlregisterinsert->execute();
            return 1;
        }

        public function search($search){
            $sql = "SELECT * FROM applyjob WHERE employer_title LIKE :search";
            $smt = Db::getDbObject()->prepare($sql);
            $smt->bindValue(':search',"%$search%",PDO::PARAM_STR);
            $smt->execute();
            $result = $smt->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        }
    }