disableSecurity()

disables template security

Description
===========

string

disableSecurity

This disables security checking on templates.

See also [`enableSecurity()`](#api.enable.security), and
[Security](#advanced.features.security).
