Advanced Features {#advanced.features}
=================

## Table of contents

- [Security](./advanced-features/advanced-features-security.md)
- [Changing settings by template](./advanced-features/advanced-features-template-settings.md)
- [Template Inheritance](./advanced-features/advanced-features-template-inheritance.md)
- [Streams](./advanced-features/advanced-features-streams.md)
- [Objects](./advanced-features/advanced-features-objects.md)
- [Static Classes](./advanced-features/advanced-features-static-classes.md)
- [Prefilters](./advanced-features/advanced-features-prefilters.md)
- [Postfilters](./advanced-features/advanced-features-postfilters.md)
- [Output Filters](./advanced-features/advanced-features-outputfilters.md)
