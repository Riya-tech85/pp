const   password = document.querySelector('#pwd');

password.addEventListener('input', checksignuppassword);

function checksignuppassword(e) {
    if (e.target.value.length >= 8 || e.target.value.length == 0) {
        password.style.border = "1px solid silver";
        password.style.borderLeft = "12px solid rgb(82, 227, 220)";
    } else {
        password.style.border = "2px solid red";
        password.style.borderLeft = "12px solid red";
    }
}