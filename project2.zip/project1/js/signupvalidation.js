const  email = document.querySelector('#email1');
 const   password = document.querySelector('#pwd');
    
email.addEventListener('input', checksignupemail);
password.addEventListener('input', checksignuppassword);


function checksignupemail(e) {
    var emailrowstring12 = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (e.target.value.match(emailrowstring12)) {
        email.style.border = "1px solid silver";
        email.style.borderLeft = "12px solid rgb(82, 227, 220)";
    } else {
        email.style.border = "2px solid red";
        email.style.borderLeft = "12px solid red";
    }
}
function checksignuppassword(e) {
    if (e.target.value.length >= 8 || e.target.value.length == 0) {
        password.style.border = "1px solid silver";
        password.style.borderLeft = "12px solid rgb(82, 227, 220)";
    } else {
        password.style.border = "2px solid red";
        password.style.borderLeft = "12px solid red";
    }
}